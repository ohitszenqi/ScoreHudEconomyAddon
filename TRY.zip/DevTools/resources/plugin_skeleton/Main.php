<?php

declare(strict_types=1);

#%{Namespace}

use pocketmine\plugin\PluginBase;

class Main extends PluginBase{

}
