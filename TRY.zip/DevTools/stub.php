<?php

require("src/DevTools/ConsoleScript.php");
